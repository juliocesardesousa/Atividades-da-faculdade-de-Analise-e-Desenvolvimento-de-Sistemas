import java.util.Scanner;

public class Ex04{
    public static void main (String [] args){
        
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("Qual valor em reais a ser convertido para dólar");
        double reais = scanner.nextDouble();
        double cambio = reais / 5.00;
        
        System.out.println("O valor em reais equivale a: $" + cambio);
        
        scanner.close();
        
    }
}
