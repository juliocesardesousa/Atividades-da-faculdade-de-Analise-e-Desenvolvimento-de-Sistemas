import java.util.Scanner;

public class Ex05{
    public static void main (String [] args){
        
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("Qual o seu peso? ");
        double peso = scanner.nextDouble();
        
        System.out.println("Qual a sua altura? ");
        double altura = scanner.nextDouble();
        
        double imc = peso / Math.pow(altura, 2);
        
        System.out.printf("O seu índice de massa corporal (IMC) é de: %.3f%n", imc);
        
        scanner.close();
        
    }
}
