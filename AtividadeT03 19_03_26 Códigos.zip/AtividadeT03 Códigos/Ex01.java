import java.util.Scanner;

public class Ex01
{
	public static void main(String[] args) {
	   
		Scanner scanner = new Scanner (System.in);
		
		System.out.println("Qual o seu primeiro nome? ");
		String nome = scanner.next();
		
		System.out.println("Qual a sua altura? ");
		double altura = scanner.nextDouble();
		
		System.out.println("Qual a sua idade? ");
		int idade = scanner.nextInt();
		
		System.out.println("Olá " + nome + ", você tem " + idade + " anos e sua altura é de " + altura + " metros");
		scanner.close();
	}
}