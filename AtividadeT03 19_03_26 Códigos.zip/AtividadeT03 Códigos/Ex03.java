import java.util.Scanner;

public class Ex03{
    public static void main (String [] args){
        
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("Digite o valor da sua primeira nota");
        double notaUm = scanner.nextDouble();
        
        System.out.println("digite o valor da sua segunda nota");
        double notaDois = scanner.nextDouble();
        
        System.out.println("Digite o valor da sua terceira nota");
        double notaTres = scanner.nextDouble();
        
        double media = (notaUm + notaDois + notaTres)/3;
        
        System.out.printf("Sua média é de: %.2f%n", media);
        
    }
}
