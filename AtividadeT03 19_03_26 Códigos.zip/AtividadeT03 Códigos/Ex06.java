import java.util.Scanner;

public class Ex06{
    public static void main (String [] args){
        
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("Digite o tempo em segundos");
        float tempo = scanner.nextFloat();
        
        scanner.close();
        
    }
}
