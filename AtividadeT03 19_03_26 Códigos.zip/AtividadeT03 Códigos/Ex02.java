import java.util.Scanner;

public class Ex02{
    public static void main (String [] args){
        
        Scanner scanner =  new Scanner (System.in);
        
        System.out.println("Qual o valor do lado do quadrado? ");
        double lado = scanner.nextDouble();
        
        System.out.println("A área do quadrado: " + Math.pow(lado,2));
    }
}